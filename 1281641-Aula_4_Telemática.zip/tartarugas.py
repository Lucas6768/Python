import turtle
import random
import time

ana = turtle.Turtle()  # Cria uma nova tartaruga
ana.shape("turtle")
ana.pencolor("red")
ana.fillcolor("red")
ana.penup()

rui = turtle.Turtle("turtle")  # Cria uma nova tartaruga
rui.color("blue")

turtle.tracer(0,0)

for i in range(5000):
    lar = turtle.window_width()
    alt = turtle.window_height()
    ana.forward(random.randint(3,6))
    ana.left(random.randint(-25, 25))
    if abs(ana.xcor()) > lar/2:
        ana.setx(-ana.xcor())
        #ana.setheading(ana.towards(0,0))
        #ana.left(180)
    if abs(ana.ycor()) > alt/2:
        ana.setheading(ana.towards(0,0))

    rui.forward(random.randint(1, 3))
    rui.left(random.randint(-25, 25))
    rui.setheading(rui.towards(ana.xcor(), ana.ycor()))

    turtle.forward(random.randint(1, 3))
    turtle.left(random.randint(-35, 25))

    
    
    turtle.update()
    time.sleep(0.01)
